package automationdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginTestng {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
    	System.getProperty(" C:\\Users\\DELL\\Downloads\\geckodriver-v0.34.0-win32\\chromedriver-mac-x64");
    	WebDriver driver = new ChromeDriver();
    	driver.get("https://www.saucedemo.com/");
    }

    @Test
    public void testValidLogin() {
        WebElement username = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login"));

        username.sendKeys("validUser");
        password.sendKeys("validPassword");
        loginButton.click();

        WebElement dashboard = driver.findElement(By.id("dashboard"));
        Assert.assertTrue(dashboard.isDisplayed(), "Login failed or dashboard is not displayed.");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
